# mxmltree x86

Demo x86 program that utilizes the mxml x86 static library for reading xml files and displaying the nodes in a treeview control

From a post on masm32.com: http://masm32.com/board/index.php?topic=5993.0
