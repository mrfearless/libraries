# cjsontree x86

Demo x86 program that utilizes the libcjson x86 static library for reading .json files and displaying the nodes in a treeview control

From a post on tuts4you.com: https://forum.tuts4you.com/topic/39996-how-to-read-json-correctly/
